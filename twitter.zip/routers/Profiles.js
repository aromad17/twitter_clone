import React from 'react'
import { useNavigate } from 'react-router-dom';
import { authService } from '../fbase'


function Profiles() {

  const navigate = useNavigate()

  const onLogOutClick = () => {
    authService.signOut();
    navigate('/'); //강제로 '/'로 페이지를 이동시킨다
  }

  return (
    <>
      <button onClick={onLogOutClick}>Log Out</button>
    </>
  )
}

export default Profiles